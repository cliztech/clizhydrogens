# Cheeky Prints – Hydrogen Starter

Quick start:
1) npm i
2) cp .env.example .env and set Shopify values
3) Place your mascot at public/assets/mascots/cheeky-hero.webp
4) npm run dev
